package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
 @MultipartConfig
public class AddFNotice extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           
                 response.setContentType("text/html;charset=UTF-8");
                 HttpSession session=request.getSession();
                 String subject=request.getParameter("subject");
                 String body=request.getParameter("body");
                 Integer id=Integer.parseInt(request.getParameter("uid"));
                 String course=request.getParameter("course");
                 Part p=request.getPart("file");
                 java.io.InputStream in;
                 String filename;
                 if(p!=null){
                     filename=p.getSubmittedFileName();
                     in=p.getInputStream();
                 }
                 else{
                     filename=null;
                     in=null;
                 }
                 java.sql.Date dob=null;
                 String d=request.getParameter("edate");
                 java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy");
                 try {
                 java.util.Date date=sdf.parse(d);
                  dob=new java.sql.Date(date.getTime());
                 } catch (ParseException ex) {
                Logger.getLogger(AddFNotice.class.getName()).log(Level.SEVERE, null, ex);
                 
                 
                 
                 db.DAO db=(db.DAO)session.getAttribute("con");
                 if(db==null){
                     try {
                         db=new db.DAO();
                     } catch (ClassNotFoundException ex2) {
                         Logger.getLogger(SUploads.class.getName()).log(Level.SEVERE, null, ex);
                     } catch (SQLException ex1) {
                         Logger.getLogger(SUploads.class.getName()).log(Level.SEVERE, null, ex);
                     }
                     session.setAttribute("con",db); }
                 int i=0;
                 try {
                     i=db.createNotice(id,subject,body,course,filename,in,dob);
                 } catch (SQLException ex3) {
                     Logger.getLogger(SUploads.class.getName()).log(Level.SEVERE, null, ex);
                 }
                 if(i>0){
                 String msg=(String)session.getAttribute("msg");
                 session.setAttribute("msg","Notice Uploaded!");
                 response.sendRedirect("faculty.jsp");
                 }
                 else
                 {
                     String msg=(String)session.getAttribute("msg");
                 session.setAttribute("msg","Error!");
                 response.sendRedirect("faculty.jsp");
                 }
                
                 
                 
             
            }
              response.sendRedirect("faculty.jsp");
            
            
        }
    }
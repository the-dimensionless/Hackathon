package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

 // @author : Sumit Singh
public class ChatPro extends HttpServlet {

   
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        
        String msg=request.getParameter("name");
       HttpSession str= request.getSession();
       
      
       db.DAO ob=null;
        try {
            ob = new db.DAO();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ChatPro.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ChatPro.class.getName()).log(Level.SEVERE, null, ex);
        }
       String message="default";
       
       
        
        try {
            message=ob.getMessage();
            
            //message="asd";
        } catch (SQLException ex) {
            Logger.getLogger(ChatPro.class.getName()).log(Level.SEVERE, null, ex);
        }
            
          
        
        
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           
            out.println( message);
           
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

 

}

package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

 @MultipartConfig
public class SUploads extends HttpServlet {

   
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session=request.getSession(false);
        if(session!=null)
        {
            int roll=Integer.parseInt(request.getParameter("roll"));
            String subject=request.getParameter("subject");
            String faculty_name=request.getParameter("fname");
            Part p=request.getPart("ufile");
            java.io.InputStream in;
            String filename;
            if(p!=null) {
                filename=p.getSubmittedFileName();
                in=p.getInputStream();
            }
            else
            {
                filename=null;
                in=null;
            }
             db.DAO db=(db.DAO)session.getAttribute("con");
            if(db==null){
                try {
                    db=new db.DAO();
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(SUploads.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(SUploads.class.getName()).log(Level.SEVERE, null, ex);
                }
                session.setAttribute("con",db); }
            int i=0;
            try {
                 i=db.student_to_faculty(roll,faculty_name,filename,in,subject);
            } catch (SQLException ex) {
                Logger.getLogger(SUploads.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            if(i==1)
            {
                session.setAttribute("msg","Upload Successful");
                response.sendRedirect("student.jsp");
            }else
            {
                session.setAttribute("msg","Upload Successful");
                response.sendRedirect("student.jsp");
            }
        
        }
        else
        {
                session.setAttribute("msg","Please Login First!!!");
                response.sendRedirect("index.jsp");
        }
    }
 }

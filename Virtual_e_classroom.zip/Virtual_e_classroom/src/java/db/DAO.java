//data access Object class
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class DAO 
{
    private Connection con;
    private PreparedStatement ps,stf,cside,submissions,getFile,getFileTeacher,getMessage,
            createNotice,getNotice,getNoticeAll;
    
    public DAO() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/eclass","root","incapp");
        ps=con.prepareStatement(
                "select * from student where roll=? and password=?");
        stf=con.prepareStatement("insert into stf values(?,?,?,?,?)");
        cside=con.prepareStatement(
                "select * from faculty where fid=? and password=? and admin=?");
        submissions=con.prepareStatement(
                "select * from stf where roll=?");
        getFile=con.prepareStatement(
                "select file_name,file from stf where file_name=?");
        getFileTeacher=con.prepareStatement(
                "select filename,file from notices where id=?");
        getMessage=con.prepareStatement("select * from chat where roll=?");
        createNotice=con.prepareStatement("insert into notices values(?,?,?,?,?,?,?");
        getNotice=con.prepareStatement("select * from notices");
    }
    public ResultSet getNotice() throws SQLException{
        ResultSet rs=getNotice.executeQuery();
        if(rs.next()){
            return rs;
        }
        else{
            return null;
        }
    }
    public int createNotice(Integer id,String subject,String body,String course,String filename,java.io.InputStream in,java.sql.Date d) throws SQLException{
        createNotice.setInt(1, id);
        createNotice.setString(2, subject);
        createNotice.setString(3, body);
        createNotice.setString(4, course);
        createNotice.setString(5, filename);
        createNotice.setBinaryStream(6, in);
        createNotice.setDate(7, d);
        
        int s=createNotice.executeUpdate();
        if(s>0){
            return 1;
        }
        else return 0;
        
    }
    public String getMessage()throws SQLException {
     
        getMessage.setInt(1, 1613210170);
        ResultSet rs=getMessage.executeQuery();
           //return rs.toString();
            String s="";
            
            
           while(rs.next()){
          s+=" "+rs.getString("msg");
           }
           return s;
    
    }
    public ArrayList getFile(String s)throws SQLException {
        getFile.setString(1, s);
        ResultSet rs=getFile.executeQuery();
        ArrayList al=new ArrayList();
        if(rs.next()) {
            al.add(rs.getString("file_name"));
            al.add(rs.getBytes("file"));
           return al;
        }
        else
        {
            return null;
        }
    }
     public ArrayList getFileTeacher(Integer i)throws SQLException {
        getFileTeacher.setInt(1, i);
        ResultSet rs=getFileTeacher.executeQuery();
        ArrayList al=new ArrayList();
        if(rs.next()) {
            al.add(rs.getString("filename"));
            al.add(rs.getBytes("file"));
           return al;
        }
        else
        {
            return null;
        }
    }
    public ResultSet submissions(Object roll)throws SQLException {
        
                submissions.setInt(1, (Integer)roll);
                ResultSet rs=submissions.executeQuery();
                
            return rs;
        
    }
    public int student_to_faculty(int roll,String fname,String file,java.io.InputStream in,String sub) throws SQLException{
       stf.setInt(1,roll);stf.setString(2,fname);
        stf.setBinaryStream(4, in);stf.setString(3,file);
        stf.setString(5, sub);
        int ans=stf.executeUpdate();
        if(ans==1)
            return 1;
        else
            return 0;
        
    }
    public HashMap searchStudent(String uid,String pass) throws SQLException
    {
        ps.setString(1, uid);
        ps.setString(2,pass);
        ResultSet rs=ps.executeQuery();
        if(rs.next()) {
            HashMap hm=new HashMap();
            hm.put("roll",rs.getInt("roll"));
            hm.put("name",rs.getString("name"));
            hm.put("father",rs.getString("father"));
            hm.put("email",rs.getString("email"));
            hm.put("course",rs.getString("course"));
            hm.put("phone",rs.getLong("phone"));
            return hm; }
        else
            return null;
    }
    public String AdminLogin(String uid,String pass) throws SQLException
    {
        cside.setString(1, uid);
        cside.setString(2, pass);
        cside.setString(3, "True");
        ResultSet rs=cside.executeQuery();
        if(rs.next())
            return rs.getString("name");
        else
            return null;
        
    }
    public String searchFaculty(String uid,String pass) throws SQLException
    {
        cside.setString(1, uid);
        cside.setString(2, pass);
        cside.setString(3, "False");
        ResultSet rs=cside.executeQuery();
        if(rs.next())
            return rs.getString("name");
        else
            return null;
    }
    
   
}
